#include <iostream>
#include <string>

using namespace std;

/*
	This is my first program in C++
*/

string helloWorld()
{
	string helloWorld = "Hello World";
	return helloWorld;
}

int main()
{
	cout << "Hello World\n";
	cout << helloWorld();
	return 0;
}
